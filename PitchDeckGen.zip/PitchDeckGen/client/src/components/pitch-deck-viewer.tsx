import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  RotateCcw, 
  FileText, 
  Download, 
  ChevronLeft, 
  ChevronRight,
  Play,
  Lightbulb,
  Star,
  PieChart,
  DollarSign,
  Rocket,
  Check,
  TriangleAlert,
  Target,
  Maximize,
  X
} from "lucide-react";

interface PitchDeckViewerProps {
  pitchDeck: {
    id: string;
    content: any;
    images: any;
    createdAt: string;
  };
  onStartOver: () => void;
}

const slideIcons = [
  Play,
  Lightbulb,
  Star,
  PieChart,
  DollarSign,
  Rocket
];

const slideNames = [
  "Problem Statement",
  "Solution Overview", 
  "Unique Value Prop",
  "Market Size",
  "Business Model",
  "Call to Action"
];

export default function PitchDeckViewer({ pitchDeck, onStartOver }: PitchDeckViewerProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const { toast } = useToast();

  const exportPptxMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/export-pptx/${pitchDeck.id}`, {});
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'pitch-deck.pptx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Your pitch deck has been downloaded as PPTX.",
      });
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : "Failed to export PPTX",
        variant: "destructive",
      });
    },
  });

  const exportPdfMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/export-pdf/${pitchDeck.id}`, {});
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'pitch-deck.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Your pitch deck has been downloaded as PDF.",
      });
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : "Failed to export PDF",
        variant: "destructive",
      });
    },
  });

  const { content, images } = pitchDeck;

  // Handle keyboard events for fullscreen
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (isFullscreen) {
        if (event.key === 'Escape') {
          setIsFullscreen(false);
        } else if (event.key === 'ArrowRight') {
          nextSlide();
        } else if (event.key === 'ArrowLeft') {
          previousSlide();
        }
      }
    };

    if (isFullscreen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isFullscreen]);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const nextSlide = () => {
    if (currentSlide < slideNames.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const previousSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const renderSlideContent = () => {
    switch (currentSlide) {
      case 0: // Problem
        return (
          <div className="h-full flex flex-col gradient-bg text-white relative rounded-xl overflow-hidden">
            <div className="absolute inset-0 bg-black/20"></div>
            <div className="relative z-10 p-8 flex-1 flex flex-col justify-center">
              <div className="mb-6">
                <span className="text-sm font-medium bg-white/20 px-3 py-1 rounded-full">
                  Problem Statement
                </span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-problem-title">
                {content.problem?.title || "Problem Statement"}
              </h1>
              <p className="text-xl lg:text-2xl opacity-90 max-w-3xl" data-testid="text-problem-description">
                {content.problem?.description || "Description of the problem your startup solves"}
              </p>
            </div>
            <div className="relative z-10 p-8">
              {images?.problem ? (
                <img 
                  src={images.problem} 
                  alt="Problem illustration" 
                  className="w-32 h-32 rounded-lg object-cover ml-auto glass-effect"
                  data-testid="img-problem"
                />
              ) : (
                <div className="w-32 h-32 bg-white/10 rounded-lg flex items-center justify-center ml-auto glass-effect">
                  <TriangleAlert className="text-white/70" size={48} />
                </div>
              )}
            </div>
          </div>
        );
      
      case 1: // Solution
        return (
          <div className="h-full p-8 flex bg-card rounded-xl">
            <div className="flex-1 flex flex-col justify-center">
              <div className="mb-6">
                <span className="text-sm font-medium bg-accent/10 text-accent px-3 py-1 rounded-full">
                  Our Solution
                </span>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-6" data-testid="text-solution-title">
                {content.solution?.title || "Our Solution"}
              </h2>
              <div className="space-y-4 text-muted-foreground">
                {content.solution?.points?.map((point: string, index: number) => (
                  <div key={index} className="flex items-start space-x-3" data-testid={`text-solution-point-${index}`}>
                    <Check className="text-accent mt-1 flex-shrink-0" size={16} />
                    <span>{point}</span>
                  </div>
                )) || (
                  <div className="flex items-start space-x-3">
                    <Check className="text-accent mt-1" size={16} />
                    <span>Solution details will be displayed here</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex-1 flex items-center justify-center">
              {images?.solution ? (
                <img 
                  src={images.solution} 
                  alt="Solution illustration" 
                  className="max-w-64 max-h-80 rounded-xl object-cover border border-border"
                  data-testid="img-solution"
                />
              ) : (
                <div className="w-64 h-80 bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl flex items-center justify-center border border-border">
                  <Lightbulb className="text-muted-foreground" size={64} />
                </div>
              )}
            </div>
          </div>
        );

      case 2: // Unique Value Prop
        return (
          <div className="h-full p-8 flex flex-col justify-center bg-card rounded-xl">
            <div className="mb-6 text-center">
              <span className="text-sm font-medium bg-primary/10 text-primary px-3 py-1 rounded-full">
                Unique Value Proposition
              </span>
            </div>
            <h2 className="text-4xl font-bold text-foreground mb-6 text-center" data-testid="text-uvp-title">
              {content.uniqueValueProp?.title || "What Makes Us Different"}
            </h2>
            <p className="text-xl text-muted-foreground text-center max-w-4xl mx-auto" data-testid="text-uvp-description">
              {content.uniqueValueProp?.description || "Our unique approach to solving the problem"}
            </p>
          </div>
        );

      case 3: // Market Size
        return (
          <div className="h-full p-8 bg-card rounded-xl">
            <div className="mb-6">
              <span className="text-sm font-medium bg-primary/10 text-primary px-3 py-1 rounded-full">
                Market Opportunity
              </span>
            </div>
            <h2 className="text-3xl font-bold text-foreground mb-8" data-testid="text-market-title">
              {content.marketSize?.title || "Market Opportunity"}
            </h2>
            
            <div className="grid grid-cols-2 gap-8 h-2/3">
              <div>
                <div className="space-y-6">
                  <div className="bg-primary/5 p-4 rounded-lg" data-testid="card-total-market">
                    <div className="text-2xl font-bold text-primary">
                      {content.marketSize?.totalMarket || "$100B"}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Addressable Market</div>
                  </div>
                  <div className="bg-accent/5 p-4 rounded-lg" data-testid="card-serviceable-market">
                    <div className="text-2xl font-bold text-accent">
                      {content.marketSize?.serviceableMarket || "$25B"}
                    </div>
                    <div className="text-sm text-muted-foreground">Serviceable Market</div>
                  </div>
                  <div className="bg-secondary p-4 rounded-lg" data-testid="card-target-users">
                    <div className="text-2xl font-bold text-foreground">
                      {content.marketSize?.targetUsers || "50M"}
                    </div>
                    <div className="text-sm text-muted-foreground">Target Users</div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                {images?.marketSize ? (
                  <img 
                    src={images.marketSize} 
                    alt="Market size visualization" 
                    className="w-full h-full rounded-xl object-cover border border-border"
                    data-testid="img-market"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl flex items-center justify-center border border-border">
                    <PieChart className="text-muted-foreground" size={64} />
                  </div>
                )}
              </div>
            </div>
          </div>
        );

      case 4: // Business Model
        return (
          <div className="h-full p-8 flex flex-col justify-center bg-card rounded-xl">
            <div className="mb-6">
              <span className="text-sm font-medium bg-accent/10 text-accent px-3 py-1 rounded-full">
                Business Model
              </span>
            </div>
            <h2 className="text-3xl font-bold text-foreground mb-6" data-testid="text-business-title">
              {content.businessModel?.title || "How We Make Money"}
            </h2>
            <div className="space-y-4 text-muted-foreground mb-6">
              {content.businessModel?.revenueStreams?.map((stream: string, index: number) => (
                <div key={index} className="flex items-start space-x-3" data-testid={`text-revenue-stream-${index}`}>
                  <DollarSign className="text-accent mt-1 flex-shrink-0" size={16} />
                  <span>{stream}</span>
                </div>
              )) || (
                <div className="flex items-start space-x-3">
                  <DollarSign className="text-accent mt-1" size={16} />
                  <span>Revenue streams will be displayed here</span>
                </div>
              )}
            </div>
            {content.businessModel?.pricing && (
              <div className="bg-primary/5 p-4 rounded-lg" data-testid="card-pricing">
                <div className="text-lg font-semibold text-foreground mb-2">Pricing Strategy</div>
                <div className="text-muted-foreground">{content.businessModel.pricing}</div>
              </div>
            )}
          </div>
        );

      case 5: // Call to Action
        return (
          <div className="h-full flex flex-col gradient-bg text-white relative rounded-xl overflow-hidden">
            <div className="absolute inset-0 bg-black/20"></div>
            <div className="relative z-10 p-8 flex-1 flex flex-col justify-center text-center">
              <div className="mb-6">
                <span className="text-sm font-medium bg-white/20 px-3 py-1 rounded-full">
                  Call to Action
                </span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-cta-title">
                {content.callToAction?.title || "Let's Build the Future Together"}
              </h1>
              <p className="text-xl lg:text-2xl opacity-90 mb-8" data-testid="text-cta-ask">
                {content.callToAction?.ask || "Join us in revolutionizing the industry"}
              </p>
              {content.callToAction?.contact && (
                <p className="text-lg opacity-80" data-testid="text-cta-contact">
                  {content.callToAction.contact}
                </p>
              )}
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="slide-in">
      {/* Results Header */}
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-8 space-y-4 lg:space-y-0">
        <div>
          <h2 className="text-3xl font-bold text-foreground" data-testid="text-deck-title">
            Your Pitch Deck is Ready!
          </h2>
          <p className="text-muted-foreground mt-1" data-testid="text-generated-at">
            Generated {new Date(pitchDeck.createdAt).toLocaleString()}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline"
            onClick={onStartOver}
            className="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition-colors"
            data-testid="button-regenerate"
          >
            <RotateCcw size={16} className="mr-2" />
            Regenerate
          </Button>
          <Button 
            onClick={() => exportPdfMutation.mutate()}
            disabled={exportPdfMutation.isPending}
            variant="outline"
            className="px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors"
            data-testid="button-download-pdf"
          >
            {exportPdfMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                Exporting...
              </>
            ) : (
              <>
                <FileText size={16} className="mr-2" />
                Download PDF
              </>
            )}
          </Button>
          <Button 
            onClick={() => exportPptxMutation.mutate()}
            disabled={exportPptxMutation.isPending}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            data-testid="button-download-pptx"
          >
            {exportPptxMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Exporting...
              </>
            ) : (
              <>
                <Download size={16} className="mr-2" />
                Download PPTX
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Slide Viewer */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* Slide Navigation */}
        <div className="lg:col-span-1">
          <Card className="bg-card border border-border rounded-lg sticky top-4">
            <CardContent className="p-4">
              <h3 className="font-semibold text-foreground mb-4">Slides</h3>
              <div className="space-y-2">
                {slideNames.map((name, index) => {
                  const Icon = slideIcons[index];
                  return (
                    <button 
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`w-full text-left p-3 rounded-lg text-sm font-medium transition-colors ${
                        currentSlide === index 
                          ? 'bg-primary text-primary-foreground' 
                          : 'hover:bg-secondary'
                      }`}
                      data-testid={`button-slide-${index}`}
                    >
                      <Icon className="inline mr-2" size={16} />
                      {index + 1}. {name}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Slide Display */}
        <div className="lg:col-span-3">
          <div className="slide-aspect bg-card border border-border rounded-xl overflow-hidden shadow-lg" data-testid={`slide-content-${currentSlide}`}>
            {renderSlideContent()}
          </div>

          {/* Slide Navigation Controls */}
          <div className="flex justify-between items-center mt-6">
            <Button 
              variant="outline"
              onClick={previousSlide}
              disabled={currentSlide === 0}
              className="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition-colors disabled:opacity-50"
              data-testid="button-previous-slide"
            >
              <ChevronLeft size={16} className="mr-2" />
              Previous
            </Button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                {Array(slideNames.length).fill(0).map((_, i) => (
                  <div 
                    key={i}
                    className={`w-2 h-2 rounded-full ${
                      currentSlide === i ? 'bg-primary' : 'bg-muted'
                    }`}
                    data-testid={`indicator-slide-${i}`}
                  />
                ))}
              </div>
              <Button 
                variant="outline"
                onClick={toggleFullscreen}
                className="px-3 py-2 border border-border rounded-lg hover:bg-secondary transition-colors"
                data-testid="button-fullscreen"
              >
                <Maximize size={16} />
              </Button>
            </div>
            <Button 
              onClick={nextSlide}
              disabled={currentSlide === slideNames.length - 1}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
              data-testid="button-next-slide"
            >
              Next
              <ChevronRight size={16} className="ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Slide Content Summary */}
      <Card className="mt-12 bg-card border border-border rounded-xl">
        <CardContent className="p-8">
          <h3 className="text-xl font-semibold text-foreground mb-6">Generated Content Summary</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-3" data-testid="summary-problem">
              <h4 className="font-medium text-foreground flex items-center">
                <TriangleAlert className="text-destructive mr-2" size={16} />
                Problem Identified
              </h4>
              <p className="text-sm text-muted-foreground">
                {content.problem?.title || "Problem identification"}
              </p>
            </div>
            <div className="space-y-3" data-testid="summary-solution">
              <h4 className="font-medium text-foreground flex items-center">
                <Lightbulb className="text-accent mr-2" size={16} />
                Solution Proposed
              </h4>
              <p className="text-sm text-muted-foreground">
                {content.solution?.title || "Solution overview"}
              </p>
            </div>
            <div className="space-y-3" data-testid="summary-market">
              <h4 className="font-medium text-foreground flex items-center">
                <Target className="text-primary mr-2" size={16} />
                Market Opportunity
              </h4>
              <p className="text-sm text-muted-foreground">
                {content.marketSize?.title || "Market analysis"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fullscreen Overlay */}
      {isFullscreen && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-95 flex flex-col">
          {/* Fullscreen Header */}
          <div className="flex justify-between items-center p-4 bg-black bg-opacity-50">
            <div className="flex items-center space-x-4 text-white">
              <h3 className="text-lg font-semibold">
                {slideNames[currentSlide]}
              </h3>
              <span className="text-sm opacity-75">
                {currentSlide + 1} / {slideNames.length}
              </span>
            </div>
            <Button
              variant="ghost"
              onClick={toggleFullscreen}
              className="text-white hover:bg-white hover:bg-opacity-20 p-2"
              data-testid="button-exit-fullscreen"
            >
              <X size={24} />
            </Button>
          </div>

          {/* Fullscreen Slide Content */}
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="w-full max-w-6xl aspect-video bg-card rounded-xl overflow-hidden shadow-2xl">
              {renderSlideContent()}
            </div>
          </div>

          {/* Fullscreen Navigation */}
          <div className="flex justify-between items-center p-4 bg-black bg-opacity-50">
            <Button
              variant="ghost"
              onClick={previousSlide}
              disabled={currentSlide === 0}
              className="text-white hover:bg-white hover:bg-opacity-20 px-6 py-3 disabled:opacity-50"
              data-testid="button-fullscreen-previous"
            >
              <ChevronLeft size={20} className="mr-2" />
              Previous
            </Button>
            
            <div className="flex items-center space-x-2">
              {Array(slideNames.length).fill(0).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    currentSlide === i ? 'bg-white' : 'bg-white bg-opacity-30'
                  }`}
                  data-testid={`fullscreen-indicator-${i}`}
                />
              ))}
            </div>

            <Button
              variant="ghost"
              onClick={nextSlide}
              disabled={currentSlide === slideNames.length - 1}
              className="text-white hover:bg-white hover:bg-opacity-20 px-6 py-3 disabled:opacity-50"
              data-testid="button-fullscreen-next"
            >
              Next
              <ChevronRight size={20} className="ml-2" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
