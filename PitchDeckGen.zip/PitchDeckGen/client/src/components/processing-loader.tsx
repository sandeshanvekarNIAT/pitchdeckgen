import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Settings, Check, Clock } from "lucide-react";

interface ProcessingLoaderProps {
  onCancel: () => void;
}

export default function ProcessingLoader({ onCancel }: ProcessingLoaderProps) {
  return (
    <div className="max-w-3xl mx-auto text-center" data-testid="processing-loader">
      <Card className="bg-card border border-border rounded-xl shadow-lg">
        <CardContent className="p-12">
          <div className="mb-8">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 loading-pulse">
              <Settings className="text-primary animate-spin" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2" data-testid="text-processing-title">
              Generating Your Pitch Deck
            </h3>
            <p className="text-muted-foreground" data-testid="text-processing-description">
              AI is analyzing your idea and creating professional content...
            </p>
          </div>

          {/* Progress Steps */}
          <div className="space-y-4 max-w-md mx-auto">
            <div className="flex items-center space-x-3" data-testid="step-analyzing">
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <Check className="text-white" size={16} />
              </div>
              <span className="text-foreground">Analyzing startup idea</span>
            </div>
            <div className="flex items-center space-x-3" data-testid="step-generating">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center loading-pulse">
                <Settings className="text-white animate-spin" size={16} />
              </div>
              <span className="text-foreground">Generating content structure</span>
            </div>
            <div className="flex items-center space-x-3" data-testid="step-visuals">
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                <Clock className="text-muted-foreground" size={16} />
              </div>
              <span className="text-muted-foreground">Creating custom visuals</span>
            </div>
            <div className="flex items-center space-x-3" data-testid="step-finalizing">
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                <Clock className="text-muted-foreground" size={16} />
              </div>
              <span className="text-muted-foreground">Finalizing presentation</span>
            </div>
          </div>

          <div className="mt-8">
            <Button 
              variant="ghost"
              onClick={onCancel}
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-cancel-generation"
            >
              Cancel Generation
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
