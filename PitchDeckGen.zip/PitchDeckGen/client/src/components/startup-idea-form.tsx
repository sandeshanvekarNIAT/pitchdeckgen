import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Lightbulb, Mic, Sparkles, ArrowRight, Brain, Image, Download, InfoIcon } from "lucide-react";

interface StartupIdeaFormProps {
  onSubmit: (startupIdea: string) => void;
  onGenerationComplete: (result: any) => void;
}

export default function StartupIdeaForm({ onSubmit, onGenerationComplete }: StartupIdeaFormProps) {
  const [startupIdea, setStartupIdea] = useState("");
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { startupIdea: string; demo?: boolean }) => {
      const endpoint = data.demo ? "/api/generate-pitch-deck-demo" : "/api/generate-pitch-deck";
      const response = await apiRequest("POST", endpoint, { startupIdea: data.startupIdea });
      return response.json();
    },
    onSuccess: (data) => {
      onGenerationComplete(data);
      toast({
        title: "Success!",
        description: "Your pitch deck has been generated successfully.",
      });
    },
    onError: (error, variables) => {
      // If it's a quota error and not already using demo, try demo mode
      if (error instanceof Error && 
          error.message.includes("quota") && 
          !variables.demo) {
        toast({
          title: "Quota Exceeded - Using Demo Mode",
          description: "OpenAI quota exceeded. Showing demo content instead.",
          variant: "default",
        });
        // Auto-retry with demo mode
        generateMutation.mutate({ ...variables, demo: true });
      } else {
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to generate pitch deck",
          variant: "destructive",
        });
      }
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (startupIdea.length < 50) {
      toast({
        title: "Description too short",
        description: "Please provide at least 50 characters describing your startup idea.",
        variant: "destructive",
      });
      return;
    }

    onSubmit(startupIdea);
    generateMutation.mutate({ startupIdea });
  };

  return (
    <div className="max-w-3xl mx-auto slide-in">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-foreground mb-4" data-testid="text-title">
          Transform Your Startup Idea
        </h2>
        <p className="text-xl text-muted-foreground" data-testid="text-subtitle">
          Describe your startup in 3-4 lines and get a professional pitch deck with AI-generated visuals
        </p>
      </div>

      <Card className="bg-card border border-border rounded-xl shadow-lg">
        <CardContent className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="startup-idea" className="block text-sm font-medium text-foreground mb-2">
                <Lightbulb className="inline mr-2 text-accent" size={16} />
                Describe Your Startup Idea
              </Label>
              <Textarea 
                id="startup-idea"
                value={startupIdea}
                onChange={(e) => setStartupIdea(e.target.value)}
                rows={6}
                className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent resize-none bg-background text-foreground placeholder-muted-foreground"
                placeholder="Example: We're building an AI-powered personal finance app that automatically categorizes expenses and provides intelligent budget recommendations. Our target market is young professionals aged 25-35 who struggle with financial planning. We use machine learning to analyze spending patterns and provide personalized insights that help users save money and achieve their financial goals."
                disabled={generateMutation.isPending}
                data-testid="textarea-startup-idea"
              />
              <div className="flex justify-between items-center mt-2">
                <p className="text-sm text-muted-foreground">Minimum 50 characters recommended</p>
                <span className="text-sm text-muted-foreground" data-testid="text-character-count">
                  {startupIdea.length}/500
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button 
                type="button" 
                variant="outline"
                className="flex items-center space-x-2 px-4 py-2 border border-border rounded-lg hover:bg-secondary transition-colors"
                disabled={generateMutation.isPending}
                data-testid="button-record-voice"
              >
                <Mic className="text-accent" size={16} />
                <span>Record Voice</span>
              </Button>
              <div className="flex-1">
                <div className="text-sm text-muted-foreground">
                  <InfoIcon className="inline mr-1" size={12} />
                  Recording converts speech to text automatically
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-6 space-y-3">
              <Button 
                type="submit" 
                className="w-full bg-primary text-primary-foreground py-4 px-6 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors flex items-center justify-center space-x-3"
                disabled={generateMutation.isPending || startupIdea.length < 50}
                data-testid="button-generate-deck"
              >
                {generateMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={20} />
                    <span>Generate Pitch Deck</span>
                    <ArrowRight size={20} />
                  </>
                )}
              </Button>
              
              <Button 
                type="button"
                onClick={() => {
                  if (startupIdea.length < 50) {
                    toast({
                      title: "Description too short",
                      description: "Please provide at least 50 characters describing your startup idea.",
                      variant: "destructive",
                    });
                    return;
                  }
                  onSubmit(startupIdea);
                  generateMutation.mutate({ startupIdea, demo: true });
                }}
                variant="outline"
                className="w-full py-4 px-6 rounded-lg font-semibold text-lg border-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-colors flex items-center justify-center space-x-3"
                disabled={generateMutation.isPending || startupIdea.length < 50}
                data-testid="button-try-demo"
              >
                <Brain size={20} />
                <span>Try Demo Mode</span>
                <ArrowRight size={20} />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Feature Preview */}
      <div className="mt-12 grid md:grid-cols-3 gap-6">
        <div className="text-center p-6 bg-card border border-border rounded-lg" data-testid="card-feature-ai">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Brain className="text-primary" size={24} />
          </div>
          <h3 className="font-semibold text-foreground mb-2">AI-Generated Content</h3>
          <p className="text-sm text-muted-foreground">GPT-5 creates structured pitch deck content tailored to your idea</p>
        </div>
        <div className="text-center p-6 bg-card border border-border rounded-lg" data-testid="card-feature-visuals">
          <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Image className="text-accent" size={24} />
          </div>
          <h3 className="font-semibold text-foreground mb-2">Custom Visuals</h3>
          <p className="text-sm text-muted-foreground">DALL-E generates unique graphics and icons for each slide</p>
        </div>
        <div className="text-center p-6 bg-card border border-border rounded-lg" data-testid="card-feature-export">
          <div className="w-12 h-12 bg-secondary/50 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Download className="text-foreground" size={24} />
          </div>
          <h3 className="font-semibold text-foreground mb-2">Export Ready</h3>
          <p className="text-sm text-muted-foreground">Download as PPTX or PDF for presentations</p>
        </div>
      </div>
    </div>
  );
}
