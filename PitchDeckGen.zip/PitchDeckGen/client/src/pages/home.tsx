import { useState } from "react";
import StartupIdeaForm from "@/components/startup-idea-form";
import ProcessingLoader from "@/components/processing-loader";
import PitchDeckViewer from "@/components/pitch-deck-viewer";
import { Button } from "@/components/ui/button";
import { ChartLine, User, HelpCircle } from "lucide-react";

type ViewState = "input" | "processing" | "result";

interface PitchDeckResult {
  id: string;
  content: any;
  images: any;
  createdAt: string;
}

export default function Home() {
  const [currentView, setCurrentView] = useState<ViewState>("input");
  const [pitchDeckResult, setPitchDeckResult] = useState<PitchDeckResult | null>(null);

  const handleFormSubmit = (startupIdea: string) => {
    setCurrentView("processing");
    // The form component will handle the API call
  };

  const handleGenerationComplete = (result: PitchDeckResult) => {
    setPitchDeckResult(result);
    setCurrentView("result");
  };

  const handleStartOver = () => {
    setCurrentView("input");
    setPitchDeckResult(null);
  };

  return (
    <div className="bg-background text-foreground min-h-screen">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <ChartLine className="text-primary-foreground" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">PitchDeck AI</h1>
                <p className="text-sm text-muted-foreground">Generate professional pitch decks instantly</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-muted-foreground hover:text-foreground transition-colors" data-testid="button-help">
                <HelpCircle size={20} />
              </button>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-signin">
                <User size={16} className="mr-2" />
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === "input" && (
          <StartupIdeaForm 
            onSubmit={handleFormSubmit} 
            onGenerationComplete={handleGenerationComplete}
          />
        )}
        
        {currentView === "processing" && (
          <ProcessingLoader onCancel={() => setCurrentView("input")} />
        )}
        
        {currentView === "result" && pitchDeckResult && (
          <PitchDeckViewer 
            pitchDeck={pitchDeckResult} 
            onStartOver={handleStartOver}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <ChartLine className="text-primary-foreground" size={16} />
              </div>
              <span className="font-semibold text-foreground">PitchDeck AI</span>
            </div>
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-foreground transition-colors">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
