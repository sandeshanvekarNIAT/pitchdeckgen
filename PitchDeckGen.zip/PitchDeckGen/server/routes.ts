import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generatePitchDeckSchema, type PitchDeckContent, type PitchDeckImages } from "@shared/schema";
import OpenAI from "openai";
import PptxGenJS from "pptxgenjs";
import jsPDF from "jspdf";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-api-key-here"
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Demo pitch deck endpoint
  app.post("/api/generate-pitch-deck-demo", async (req, res) => {
    try {
      const { startupIdea } = generatePitchDeckSchema.parse(req.body);

      // Sample pitch deck content
      const content: PitchDeckContent = {
        problem: {
          title: "Traditional Finance Apps Are Failing Young Professionals",
          description: "Young professionals struggle with budgeting and financial planning. Existing apps are either too complex, lack personalization, or fail to provide actionable insights, leaving 73% of millennials feeling overwhelmed by their finances."
        },
        solution: {
          title: "AI-Powered Personal Finance Assistant",
          points: [
            "Automatically categorizes all expenses using machine learning",
            "Provides personalized budget recommendations based on spending patterns",
            "Delivers intelligent insights to help users save money effortlessly",
            "Adapts to user behavior and goals over time for maximum effectiveness"
          ]
        },
        uniqueValueProp: {
          title: "The Only Finance App That Actually Learns How You Spend",
          description: "Unlike static budgeting apps, our AI adapts to your unique spending habits and life changes, providing personalized recommendations that actually work for your lifestyle and financial goals."
        },
        marketSize: {
          title: "Massive Market Opportunity",
          totalMarket: "$12.5B",
          serviceableMarket: "$3.2B",
          targetUsers: "28M young professionals"
        },
        businessModel: {
          title: "Multiple Revenue Streams",
          revenueStreams: [
            "Freemium subscription model ($9.99/month premium)",
            "Affiliate commissions from recommended financial products",
            "Premium insights and advanced analytics ($19.99/month)",
            "White-label solution for banks and credit unions"
          ],
          pricing: "Freemium model starting at $9.99/month with premium features at $19.99/month"
        },
        callToAction: {
          title: "Ready to Transform Personal Finance?",
          ask: "We're seeking $2M in seed funding to scale our AI technology and capture market share",
          contact: "Contact us at founders@financeai.com or schedule a demo today"
        }
      };

      // Sample images using placeholder service
      const images: PitchDeckImages = {
        problem: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=300&fit=crop&crop=center",
        solution: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop&crop=center",
        uniqueValueProp: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop&crop=center",
        marketSize: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop&crop=center",
        businessModel: "https://images.unsplash.com/photo-1554224154-26032fced8bd?w=400&h=300&fit=crop&crop=center",
        callToAction: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop&crop=center"
      };

      // Save to storage
      const pitchDeck = await storage.createPitchDeck(startupIdea, content, images);

      res.json({
        id: pitchDeck.id,
        content,
        images,
        createdAt: pitchDeck.createdAt
      });

    } catch (error) {
      console.error("Error generating demo pitch deck:", error);
      res.status(500).json({ 
        error: "Failed to generate demo pitch deck", 
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Generate pitch deck endpoint
  app.post("/api/generate-pitch-deck", async (req, res) => {
    try {
      const { startupIdea } = generatePitchDeckSchema.parse(req.body);

      // Generate structured content with GPT-5
      const contentResponse = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a professional pitch deck generator. Generate structured pitch deck content in JSON format with the following sections: problem, solution, uniqueValueProp, marketSize, businessModel, callToAction. Each section should have appropriate fields for a professional presentation."
          },
          {
            role: "user",
            content: `Create a professional pitch deck for this startup idea: ${startupIdea}. 
            
            Return JSON with this structure:
            {
              "problem": {"title": "string", "description": "string"},
              "solution": {"title": "string", "points": ["string"]},
              "uniqueValueProp": {"title": "string", "description": "string"}, 
              "marketSize": {"title": "string", "totalMarket": "string", "serviceableMarket": "string", "targetUsers": "string"},
              "businessModel": {"title": "string", "revenueStreams": ["string"], "pricing": "string"},
              "callToAction": {"title": "string", "ask": "string", "contact": "string"}
            }`
          }
        ],
        response_format: { type: "json_object" },
      });

      const content: PitchDeckContent = JSON.parse(contentResponse.choices[0].message.content || "{}");

      // Generate images with DALL-E 3
      const images: PitchDeckImages = {};
      
      try {
        // Generate problem illustration
        const problemImage = await openai.images.generate({
          model: "dall-e-3",
          prompt: `Create a professional, minimalist illustration representing this business problem: ${content.problem.title}. Use a clean, corporate style with muted colors suitable for a pitch deck.`,
          size: "1024x1024",
          quality: "standard",
        });
        images.problem = problemImage.data?.[0]?.url;

        // Generate solution illustration  
        const solutionImage = await openai.images.generate({
          model: "dall-e-3",
          prompt: `Create a professional illustration showing the solution: ${content.solution.title}. Show technology, innovation, and positive outcomes. Use clean, modern design suitable for business presentation.`,
          size: "1024x1024",
          quality: "standard",
        });
        images.solution = solutionImage.data?.[0]?.url;

        // Generate market visualization
        const marketImage = await openai.images.generate({
          model: "dall-e-3",
          prompt: `Create a professional infographic or chart visualization representing market opportunity and growth. Include elements like charts, graphs, and market data visualization. Clean, business-appropriate style.`,
          size: "1024x1024",
          quality: "standard",
        });
        images.marketSize = marketImage.data?.[0]?.url;

      } catch (imageError) {
        console.error("Error generating images:", imageError);
        // Continue without images if DALL-E fails
      }

      // Save to storage
      const pitchDeck = await storage.createPitchDeck(startupIdea, content, images);

      res.json({
        id: pitchDeck.id,
        content,
        images,
        createdAt: pitchDeck.createdAt
      });

    } catch (error) {
      console.error("Error generating pitch deck:", error);
      
      // Handle OpenAI specific errors
      if (error && typeof error === 'object' && 'error' in error) {
        const openaiError = error as any;
        if (openaiError.error?.code === 'insufficient_quota') {
          return res.status(429).json({
            error: "OpenAI quota exceeded",
            message: "The OpenAI API quota has been exceeded. Please check your OpenAI account billing and usage limits.",
            code: "QUOTA_EXCEEDED"
          });
        }
        if (openaiError.error?.code === 'rate_limit_exceeded') {
          return res.status(429).json({
            error: "Rate limit exceeded",
            message: "Too many requests to OpenAI. Please try again in a moment.",
            code: "RATE_LIMIT"
          });
        }
      }
      
      res.status(500).json({ 
        error: "Failed to generate pitch deck", 
        message: error instanceof Error ? error.message : "Unknown error",
        code: "GENERATION_FAILED"
      });
    }
  });

  // Export PPTX endpoint
  app.post("/api/export-pptx/:id", async (req, res) => {
    try {
      const pitchDeck = await storage.getPitchDeck(req.params.id);
      if (!pitchDeck) {
        return res.status(404).json({ error: "Pitch deck not found" });
      }

      const content = pitchDeck.content as PitchDeckContent;
      const images = pitchDeck.images as PitchDeckImages;

      // Create PowerPoint presentation
      const pptx = new PptxGenJS();
      pptx.layout = "LAYOUT_16x9";

      // Slide 1: Problem
      const slide1 = pptx.addSlide();
      slide1.background = { fill: "363636" };
      slide1.addText(content.problem.title, {
        x: 0.5, y: 2, w: 8, h: 1.5,
        fontSize: 36, bold: true, color: "FFFFFF"
      });
      slide1.addText(content.problem.description, {
        x: 0.5, y: 4, w: 8, h: 2,
        fontSize: 18, color: "FFFFFF"
      });

      // Slide 2: Solution
      const slide2 = pptx.addSlide();
      slide2.addText(content.solution.title, {
        x: 0.5, y: 1, w: 8, h: 1,
        fontSize: 32, bold: true, color: "333333"
      });
      content.solution.points.forEach((point, index) => {
        slide2.addText(`• ${point}`, {
          x: 0.5, y: 2.5 + (index * 0.8), w: 8, h: 0.6,
          fontSize: 16, color: "555555"
        });
      });

      // Slide 3: Market Size
      const slide3 = pptx.addSlide();
      slide3.addText(content.marketSize.title, {
        x: 0.5, y: 1, w: 8, h: 1,
        fontSize: 32, bold: true, color: "333333"
      });
      slide3.addText(`Total Market: ${content.marketSize.totalMarket}`, {
        x: 0.5, y: 2.5, w: 8, h: 0.6,
        fontSize: 18, color: "555555"
      });
      slide3.addText(`Serviceable Market: ${content.marketSize.serviceableMarket}`, {
        x: 0.5, y: 3.3, w: 8, h: 0.6,
        fontSize: 18, color: "555555"
      });

      // Slide 4: Business Model
      const slide4 = pptx.addSlide();
      slide4.addText(content.businessModel.title, {
        x: 0.5, y: 1, w: 8, h: 1,
        fontSize: 32, bold: true, color: "333333"
      });
      content.businessModel.revenueStreams.forEach((stream, index) => {
        slide4.addText(`• ${stream}`, {
          x: 0.5, y: 2.5 + (index * 0.8), w: 8, h: 0.6,
          fontSize: 16, color: "555555"
        });
      });

      // Slide 5: Call to Action
      const slide5 = pptx.addSlide();
      slide5.background = { fill: "4F46E5" };
      slide5.addText(content.callToAction.title, {
        x: 0.5, y: 2, w: 8, h: 1.5,
        fontSize: 36, bold: true, color: "FFFFFF"
      });
      slide5.addText(content.callToAction.ask, {
        x: 0.5, y: 4, w: 8, h: 1,
        fontSize: 20, color: "FFFFFF"
      });

      // Generate and send PPTX
      const pptxBuffer = await pptx.write({ outputType: "base64" });
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
      res.setHeader('Content-Disposition', 'attachment; filename="pitch-deck.pptx"');
      res.send(Buffer.from(pptxBuffer as string, 'base64'));

    } catch (error) {
      console.error("Error exporting PPTX:", error);
      res.status(500).json({ error: "Failed to export PPTX" });
    }
  });

  // Export PDF endpoint
  app.post("/api/export-pdf/:id", async (req, res) => {
    try {
      const pitchDeck = await storage.getPitchDeck(req.params.id);
      if (!pitchDeck) {
        return res.status(404).json({ error: "Pitch deck not found" });
      }

      const content = pitchDeck.content as PitchDeckContent;

      // Create PDF document
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: 'a4'
      });

      // Set font
      pdf.setFont('helvetica');
      
      // Slide 1: Problem
      pdf.setFillColor(54, 54, 54);
      pdf.rect(0, 0, 297, 210, 'F');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(28);
      pdf.text(content.problem.title, 20, 60);
      pdf.setFontSize(16);
      pdf.text(pdf.splitTextToSize(content.problem.description, 250), 20, 80);

      // Add new page for Solution
      pdf.addPage();
      pdf.setFillColor(255, 255, 255);
      pdf.rect(0, 0, 297, 210, 'F');
      pdf.setTextColor(51, 51, 51);
      pdf.setFontSize(24);
      pdf.text(content.solution.title, 20, 40);
      pdf.setFontSize(14);
      let yPosition = 60;
      content.solution.points.forEach((point: string, index: number) => {
        pdf.text(`• ${point}`, 20, yPosition + (index * 15));
      });

      // Add new page for Market Size
      pdf.addPage();
      pdf.setTextColor(51, 51, 51);
      pdf.setFontSize(24);
      pdf.text(content.marketSize.title, 20, 40);
      pdf.setFontSize(16);
      pdf.text(`Total Market: ${content.marketSize.totalMarket}`, 20, 70);
      pdf.text(`Serviceable Market: ${content.marketSize.serviceableMarket}`, 20, 90);
      pdf.text(`Target Users: ${content.marketSize.targetUsers}`, 20, 110);

      // Add new page for Business Model
      pdf.addPage();
      pdf.setFontSize(24);
      pdf.text(content.businessModel.title, 20, 40);
      pdf.setFontSize(14);
      yPosition = 60;
      content.businessModel.revenueStreams.forEach((stream: string, index: number) => {
        pdf.text(`• ${stream}`, 20, yPosition + (index * 15));
      });
      if (content.businessModel.pricing) {
        pdf.setFontSize(16);
        pdf.text("Pricing Strategy:", 20, yPosition + (content.businessModel.revenueStreams.length * 15) + 20);
        pdf.setFontSize(14);
        pdf.text(pdf.splitTextToSize(content.businessModel.pricing, 250), 20, yPosition + (content.businessModel.revenueStreams.length * 15) + 35);
      }

      // Add new page for Call to Action
      pdf.addPage();
      pdf.setFillColor(79, 70, 229);
      pdf.rect(0, 0, 297, 210, 'F');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(28);
      pdf.text(pdf.splitTextToSize(content.callToAction.title, 250), 20, 60);
      pdf.setFontSize(16);
      pdf.text(pdf.splitTextToSize(content.callToAction.ask, 250), 20, 90);
      if (content.callToAction.contact) {
        pdf.setFontSize(14);
        pdf.text(content.callToAction.contact, 20, 120);
      }

      // Generate PDF buffer
      const pdfBuffer = Buffer.from(pdf.output('arraybuffer'));
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="pitch-deck.pdf"');
      res.send(pdfBuffer);

    } catch (error) {
      console.error("Error exporting PDF:", error);
      res.status(500).json({ error: "Failed to export PDF" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
