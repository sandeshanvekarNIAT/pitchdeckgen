import { type PitchDeck, type InsertPitchDeck, type PitchDeckContent, type PitchDeckImages } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createPitchDeck(startupIdea: string, content: PitchDeckContent, images?: PitchDeckImages): Promise<PitchDeck>;
  getPitchDeck(id: string): Promise<PitchDeck | undefined>;
}

export class MemStorage implements IStorage {
  private pitchDecks: Map<string, PitchDeck>;

  constructor() {
    this.pitchDecks = new Map();
  }

  async createPitchDeck(startupIdea: string, content: PitchDeckContent, images?: PitchDeckImages): Promise<PitchDeck> {
    const id = randomUUID();
    const pitchDeck: PitchDeck = {
      id,
      startupIdea,
      content: content as any,
      images: images as any,
      createdAt: new Date(),
    };
    this.pitchDecks.set(id, pitchDeck);
    return pitchDeck;
  }

  async getPitchDeck(id: string): Promise<PitchDeck | undefined> {
    return this.pitchDecks.get(id);
  }
}

export const storage = new MemStorage();
