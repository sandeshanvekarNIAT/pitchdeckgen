import { sql } from "drizzle-orm";
import { pgTable, text, varchar, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const pitchDecks = pgTable("pitch_decks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  startupIdea: text("startup_idea").notNull(),
  content: json("content").notNull(),
  images: json("images"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPitchDeckSchema = createInsertSchema(pitchDecks).pick({
  startupIdea: true,
});

export const generatePitchDeckSchema = z.object({
  startupIdea: z.string().min(50, "Please provide at least 50 characters describing your startup idea"),
});

export type InsertPitchDeck = z.infer<typeof insertPitchDeckSchema>;
export type PitchDeck = typeof pitchDecks.$inferSelect;
export type GeneratePitchDeckRequest = z.infer<typeof generatePitchDeckSchema>;

export interface PitchDeckContent {
  problem: {
    title: string;
    description: string;
  };
  solution: {
    title: string;
    points: string[];
  };
  uniqueValueProp: {
    title: string;
    description: string;
  };
  marketSize: {
    title: string;
    totalMarket: string;
    serviceableMarket: string;
    targetUsers: string;
  };
  businessModel: {
    title: string;
    revenueStreams: string[];
    pricing: string;
  };
  callToAction: {
    title: string;
    ask: string;
    contact: string;
  };
}

export interface PitchDeckImages {
  problem?: string;
  solution?: string;
  uniqueValueProp?: string;
  marketSize?: string;
  businessModel?: string;
  callToAction?: string;
}
